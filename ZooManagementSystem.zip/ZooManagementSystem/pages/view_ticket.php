<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['authenticated']) || $_SESSION['user_type'] !== 'visitor') {
    header("Location: ../public_html/login.php");
    exit();
}

require_once '../classes/database.php';

$visitorId = $_SESSION['visitor_id'];
$db = new Database();

$query = "SELECT * FROM tickets WHERE visitor_id = ?";
$tickets = $db->executeQuery($query, [$visitorId]);

ob_start();
?>

<link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
<style>
body {
    font-family: "Segoe UI", sans-serif;
    background: #f4f6f9;
    padding: 20px;
}
.container {
    max-width: 900px;
    margin: auto;
}
.ticket-card {
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    padding: 25px;
    margin-bottom: 25px;
    transition: 0.3s ease;
    border-left: 5px solid #007bff;
}
.ticket-card:hover {
    transform: translateY(-3px);
}
.ticket-header {
    font-size: 22px;
    font-weight: bold;
    color: #007bff;
    margin-bottom: 15px;
}
.ticket-info {
    font-size: 16px;
    color: #343a40;
    margin-bottom: 5px;
}
.total-amount {
    font-weight: bold;
    color: #28a745;
    margin-top: 10px;
}
.print-btn {
    background: #28a745;
    border: none;
    padding: 10px 16px;
    font-weight: bold;
    color: white;
    border-radius: 6px;
    margin-top: 15px;
    transition: background 0.3s ease;
}
.print-btn:hover {
    background: #218838;
}
</style>

<div class="container my-5">
  <h2 class="mb-4">🎫 Your Tickets</h2>

  <?php if ($tickets && count($tickets) > 0): ?>
    <?php foreach (array_reverse($tickets) as $index => $ticket): ?>
      <div class="ticket-card" id="ticket<?= $index ?>">
        <div class="ticket-header">Ticket #<?= htmlspecialchars($ticket['ticket_id']) ?></div>
        <div class="ticket-info">Book Name: <?= htmlspecialchars($ticket['book_name']) ?></div>
        <div class="ticket-info">Date: <?= htmlspecialchars($ticket['t_date']) ?></div>
        <div class="ticket-info">Children: <?= htmlspecialchars($ticket['child_num']) ?></div>
        <div class="ticket-info">Students: <?= htmlspecialchars($ticket['student_num']) ?></div>
        <div class="ticket-info">Regular: <?= htmlspecialchars($ticket['regular_num']) ?></div>
        <div class="ticket-info total-amount">
          Total Amount: ₹<?= $ticket['child_num'] * 50 + $ticket['student_num'] * 100 + $ticket['regular_num'] * 200 ?>
        </div>
        <button class="print-btn" onclick="printTicket('ticket<?= $index ?>')">🖨 Print Ticket</button>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <div class="alert alert-info">No tickets found.</div>
  <?php endif; ?>

  <a href="../public_html/home.php" class="btn btn-secondary mt-4">← Back to Home</a>
</div>

<script>
function printTicket(ticketId) {
  const original = document.getElementById(ticketId);
  const cloned = original.cloneNode(true);

  const qrCode = document.createElement("div");
  qrCode.style.textAlign = "center";
  qrCode.style.marginTop = "20px";
  qrCode.innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${ticketId}" alt="QR Code">`;
  cloned.appendChild(qrCode);

  const printWindow = window.open('', '_blank', 'width=800,height=700');
  const styles = `
    <style>
      body {
        font-family: 'Arial', sans-serif;
        padding: 30px;
        background: #fff;
        text-align: center;
      }
      .ticket-card {
        max-width: 600px;
        margin: auto;
        border: 2px dashed #007bff;
        border-radius: 15px;
        padding: 25px;
        background: #fefefe;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        text-align: left;
      }
      .ticket-header {
        font-size: 22px;
        font-weight: bold;
        color: #007bff;
        margin-bottom: 20px;
        border-bottom: 1px solid #ccc;
        padding-bottom: 10px;
      }
      .ticket-info {
        font-size: 16px;
        margin: 5px 0;
        color: #333;
      }
      .total-amount {
        font-size: 18px;
        font-weight: bold;
        color: #28a745;
        margin-top: 15px;
      }
      .ticket-footer {
        font-size: 12px;
        text-align: center;
        color: #666;
        margin-top: 20px;
        border-top: 1px dashed #ccc;
        padding-top: 10px;
      }
    </style>
  `;

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Print Ticket</title>
      ${styles}
    </head>
    <body>
      <div class="ticket-card">
        ${cloned.innerHTML}
        <div class="ticket-footer">
          Thank you for visiting the Zoo 🐾<br>
          Zoo Management System – Karnataka
        </div>
      </div>
    </body>
    </html>
  `);

  printWindow.document.close();
  printWindow.onload = function () {
    printWindow.focus();
    printWindow.print();
    setTimeout(() => printWindow.close(), 1000);
  };
}
</script>

<?php
$content = ob_get_clean();
$title = "Your Tickets";
// Do NOT require index.php again here – it’s already called externally
?>
