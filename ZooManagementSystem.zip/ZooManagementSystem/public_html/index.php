<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Load required files
require_once '../db/db_connect.php';
require_once '../classes/table.php';
require_once '../functions/functions.php';

// Load the requested page or default to home
if (isset($_GET['page'])) {
    require_once '../pages/' . $_GET['page'] . '.php';
} else {
    require_once '../pages/home.php';
}

// Set default values if not set by the included page
if (!isset($title)) {
    $title = "Zoo Management System";
}
if (!isset($content)) {
    $content = "<p>Welcome to the Zoo Management System</p>";
}

// Prepare and render the layout
$variables = [
    'title' => $title,
    'content' => $content
];

echo loadTemplate('../templates/layout.php', $variables);
?>
