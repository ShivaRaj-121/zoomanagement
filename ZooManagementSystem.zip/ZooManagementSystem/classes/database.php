<?php
class Database {
    private $host = 'localhost';
    private $db_name = 'zoomanagement';  // Change this to your actual database name
    private $username = 'root';   // MySQL username (default is 'root' for XAMPP)
    private $password = '';       // MySQL password (often empty for local XAMPP)
    private $conn;

    public function __construct() {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->db_name);
        if ($this->conn->connect_error) {
            die("Database connection failed: " . $this->conn->connect_error);
        }
    }

    public function executeQuery($query, $params = []) {
        $stmt = $this->conn->prepare($query);
        if ($params) {
            $types = str_repeat("s", count($params));
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    public function __destruct() {
        $this->conn->close();
    }
}
?>
